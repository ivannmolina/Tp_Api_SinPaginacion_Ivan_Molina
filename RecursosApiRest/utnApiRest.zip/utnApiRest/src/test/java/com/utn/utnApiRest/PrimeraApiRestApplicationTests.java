package com.utn.utnApiRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeraApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
