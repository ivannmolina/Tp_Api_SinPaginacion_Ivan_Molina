package com.utn.utnApiRest.services;

import com.utn.utnApiRest.entities.Persona;

public interface PersonaService extends BaseService<Persona,Long> {

}
